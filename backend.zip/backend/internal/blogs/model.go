package blogs

import (
	"github.com/iankencruz/threefive/internal/core/blocks"
	"github.com/iankencruz/threefive/internal/generated"
)

// Wrapper struct for hydrated blogs
type BlogWithBlocks struct {
	Blog   generated.Blog `json:"blog"`
	Blocks []blocks.Block `json:"blocks"`
}
