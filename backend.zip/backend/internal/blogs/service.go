package blogs

import (
	"context"

	"github.com/iankencruz/threefive/internal/generated"
)

type BlogService struct {
	repo Repository
}

func NewBlogService(r Repository) *BlogService {
	return &BlogService{
		repo: r,
	}
}

func (s *BlogService) GetBySlug(ctx context.Context, slug string) (BlogWithBlocks, error) {
	blog, err := s.repo.GetBySlug(ctx, slug)
	if err != nil {
		return BlogWithBlocks{}, err
	}

	blocks, err := s.repo.GetBlocksForBlog(ctx, blog.ID)
	if err != nil {
		return BlogWithBlocks{}, err
	}

	return BlogWithBlocks{
		Blog:   blog,
		Blocks: blocks,
	}, nil
}

func (s *BlogService) List(ctx context.Context) ([]generated.Blog, error) {
	return s.repo.List(ctx)
}
